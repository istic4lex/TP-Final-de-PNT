package com.example.tpfinalpent2.interfaz.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tpfinalpent2.datos.almacenamiento.Usuario
import com.example.tpfinalpent2.datos.repositorio.RepositorioUsuario
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class LoginViewModel(
    private val repositorioUsuario: RepositorioUsuario
) : ViewModel() {

    private val _loginExitoso = MutableStateFlow(false)
    val loginExitoso: StateFlow<Boolean> = _loginExitoso

    private val _mensajeError = MutableStateFlow<String?>(null)
    val mensajeError: StateFlow<String?> = _mensajeError

    private val _redirigirAMenu = MutableStateFlow(false)
    val redirigirAMenu: StateFlow<Boolean> = _redirigirAMenu

    init {
        verificarSesionActiva()
    }

    private fun verificarSesionActiva() {
        viewModelScope.launch {
            repositorioUsuario.sesionActiva.collect { activa ->
                if (activa) {
                    val usuario = repositorioUsuario.verificarSesionGuardada()
                    if (usuario != null) {
                        _redirigirAMenu.value = true
                    }
                }
            }
        }
    }

    fun login(nombreUsuario: String, contrasena: String, recordarSesion: Boolean) {
        viewModelScope.launch {
            if (nombreUsuario.isEmpty()) {
                _mensajeError.value = "El nombre de usuario no puede estar vacío"
                return@launch
            }

            if (contrasena.isEmpty()) {
                _mensajeError.value = "La contraseña no puede estar vacía"
                return@launch
            }

            val valido = repositorioUsuario.validarLogin(nombreUsuario, contrasena)

            if (valido) {
                val usuario = Usuario(nombreUsuario, contrasena, recordarSesion)
                repositorioUsuario.iniciarSesion(usuario, recordarSesion)
                _loginExitoso.value = true
                _mensajeError.value = null
            } else {
                _mensajeError.value = "Usuario o contraseña incorrecto"
                _loginExitoso.value = false
            }
        }
    }

    fun limpiarMensajeError() {
        _mensajeError.value = null
    }
}