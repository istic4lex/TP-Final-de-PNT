package com.example.tpfinalpent2.datos.repositorio

import com.example.tpfinalpent2.datos.almacenamiento.DataStoreManager
import com.example.tpfinalpent2.datos.almacenamiento.Usuario
import kotlinx.coroutines.flow.Flow

class RepositorioUsuario(
    private val dataStoreManager: DataStoreManager
) {

    val usuario: Flow<Usuario?> = dataStoreManager.obtenerUsuario
    val sesionActiva: Flow<Boolean> = dataStoreManager.esSesionActiva

    suspend fun validarLogin(nombreUsuario: String, contrasena: String): Boolean {
        return nombreUsuario.isNotEmpty() && contrasena.isNotEmpty()
    }

    suspend fun iniciarSesion(usuario: Usuario, recordarSesion: Boolean) {
        dataStoreManager.guardarUsuario(usuario, recordarSesion)
    }

    suspend fun cerrarSesion() {
        dataStoreManager.cerrarSesion()
    }

    suspend fun verificarSesionGuardada(): Usuario? {
        var usuarioGuardado: Usuario? = null
        usuario.collect { usuarioGuardado = it }
        return usuarioGuardado
    }
}