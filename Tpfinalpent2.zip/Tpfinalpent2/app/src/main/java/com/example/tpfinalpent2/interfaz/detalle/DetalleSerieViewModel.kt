package com.example.tpfinalpent2.interfaz.detalle

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tpfinalpent2.datos.modelo.Serie
import com.example.tpfinalpent2.datos.repositorio.RepositorioSerie
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class DetalleSerieViewModel(
    private val repositorioSerie: RepositorioSerie
) : ViewModel() {

    private val _serie = MutableStateFlow<Serie?>(null)
    val serie: StateFlow<Serie?> = _serie

    private val _cargando = MutableStateFlow(false)
    val cargando: StateFlow<Boolean> = _cargando

    private val _mensajeError = MutableStateFlow<String?>(null)
    val mensajeError: StateFlow<String?> = _mensajeError

    fun cargarSerie(id: Int) {
        viewModelScope.launch {
            _cargando.value = true
            _mensajeError.value = null

            val resultado = repositorioSerie.obtenerSeriePorId(id)

            resultado.fold(
                onSuccess = { serieDetallada ->
                    _serie.value = serieDetallada
                    _cargando.value = false
                },
                onFailure = { exception ->
                    _mensajeError.value = exception.message ?: "Error al cargar la serie"
                    _cargando.value = false
                }
            )
        }
    }

    fun limpiarError() {
        _mensajeError.value = null
    }
}