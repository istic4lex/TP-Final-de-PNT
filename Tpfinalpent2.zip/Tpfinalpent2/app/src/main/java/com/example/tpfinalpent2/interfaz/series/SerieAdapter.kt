package com.example.tpfinalpent2.interfaz.series

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.tpfinalpent2.R
import com.example.tpfinalpent2.datos.modelo.ShowSearchResult

class SerieAdapter(
    private val onItemClick: (Int) -> Unit
) : RecyclerView.Adapter<SerieAdapter.SerieViewHolder>() {

    private var series: List<ShowSearchResult> = emptyList()

    inner class SerieViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imagenSerie: ImageView = itemView.findViewById(R.id.imagenSerie)
        val nombreSerie: TextView = itemView.findViewById(R.id.nombreSerie)
        val generoSerie: TextView = itemView.findViewById(R.id.generoSerie)
        val ratingSerie: TextView = itemView.findViewById(R.id.ratingSerie)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SerieViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_serie, parent, false)
        return SerieViewHolder(view)
    }

    override fun onBindViewHolder(holder: SerieViewHolder, position: Int) {
        val showResult = series[position]
        val serie = showResult.show

        holder.nombreSerie.text = serie.name
        holder.generoSerie.text = serie.genres?.joinToString(", ") ?: "Sin género"
        holder.ratingSerie.text = serie.rating?.average?.toString() ?: "N/A"

        val imageUrl = serie.imagen?.medium
        if (!imageUrl.isNullOrEmpty()) {
            Glide.with(holder.imagenSerie.context)
                .load(imageUrl)
                .placeholder(android.R.drawable.ic_menu_gallery)
                .error(android.R.drawable.ic_menu_report_image)
                .into(holder.imagenSerie)
        }

        holder.itemView.setOnClickListener {
            onItemClick(serie.id)
        }
    }

    override fun getItemCount(): Int = series.size

    fun actualizarSeries(nuevasSeries: List<ShowSearchResult>) {
        series = nuevasSeries
        notifyDataSetChanged()
    }
}