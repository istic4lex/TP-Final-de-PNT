package com.example.tpfinalpent2.utilidades

object Constantes {
    const val PREFS_NOMBRE = "prefs_app"
    const val KEY_USUARIO = "usuario"
    const val KEY_CONTRASENA = "contrasena"
    const val KEY_SESION_ACTIVA = "sesion_activa"
    const val KEY_RECORDAR_SESION = "recordar_sesion"

    const val EXTRA_SERIE_ID = "serie_id"
    const val EXTRA_SERIE_NOMBRE = "serie_nombre"

    const val PAGINA_INICIAL = 0
    const val LIMITE_RESULTADOS = 20
}