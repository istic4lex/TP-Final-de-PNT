package com.example.tpfinalpent2.interfaz.series

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tpfinalpent2.datos.modelo.Serie
import com.example.tpfinalpent2.datos.modelo.ShowSearchResult
import com.example.tpfinalpent2.datos.repositorio.RepositorioSerie
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class SerieViewModel(
    private val repositorioSerie: RepositorioSerie
) : ViewModel() {

    private val _series = MutableStateFlow<List<ShowSearchResult>>(emptyList())
    val series: StateFlow<List<ShowSearchResult>> = _series

    private val _cargando = MutableStateFlow(false)
    val cargando: StateFlow<Boolean> = _cargando

    private val _mensajeError = MutableStateFlow<String?>(null)
    val mensajeError: StateFlow<String?> = _mensajeError

    private val _serieSeleccionada = MutableStateFlow<Serie?>(null)
    val serieSeleccionada: StateFlow<Serie?> = _serieSeleccionada

    fun buscarSeries(termino: String) {
        if (termino.isEmpty()) return

        viewModelScope.launch {
            _cargando.value = true
            _mensajeError.value = null

            val resultado = repositorioSerie.buscarSeries(termino)

            resultado.fold(
                onSuccess = { listaSeries ->
                    _series.value = listaSeries
                    _cargando.value = false
                },
                onFailure = { exception ->
                    _mensajeError.value = exception.message ?: "Error al buscar series"
                    _cargando.value = false
                }
            )
        }
    }

    fun cargarSerieDetalle(id: Int) {
        viewModelScope.launch {
            _cargando.value = true
            val resultado = repositorioSerie.obtenerSeriePorId(id)

            resultado.fold(
                onSuccess = { serie ->
                    _serieSeleccionada.value = serie
                    _cargando.value = false
                },
                onFailure = { exception ->
                    _mensajeError.value = exception.message ?: "Error al cargar detalles"
                    _cargando.value = false
                }
            )
        }
    }

    fun limpiarError() {
        _mensajeError.value = null
    }
}