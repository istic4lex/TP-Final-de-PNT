package com.example.tpfinalpent2.datos.almacenamiento

data class Usuario(
    val nombreUsuario: String,
    val contrasena: String,
    val recordarSesion: Boolean = false
)