package com.example.tpfinalpent2.datos.modelo

data class Rating(
    val average: Double?
)