package com.example.tpfinalpent2.datos.modelo

data class Imagen(
    val medium: String?,
    val original: String?
)