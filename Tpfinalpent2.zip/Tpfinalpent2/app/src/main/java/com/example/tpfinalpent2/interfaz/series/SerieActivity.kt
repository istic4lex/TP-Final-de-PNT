package com.example.tpfinalpent2.interfaz.series

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tpfinalpent2.R
import com.example.tpfinalpent2.datos.repositorio.RepositorioSerie
import com.example.tpfinalpent2.interfaz.detalle.DetalleSerieActivity
import kotlinx.coroutines.launch

class SerieActivity : AppCompatActivity() {

    private lateinit var repositorioSerie: RepositorioSerie

    private val viewModel: SerieViewModel by viewModels {
        object : androidx.lifecycle.ViewModelProvider.Factory {
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return SerieViewModel(repositorioSerie) as T
            }
        }
    }

    private lateinit var recyclerViewSeries: RecyclerView
    private lateinit var editTextBusqueda: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var adapter: SerieAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_serie)

        repositorioSerie = RepositorioSerie()

        recyclerViewSeries = findViewById(R.id.recyclerViewSeries)
        editTextBusqueda = findViewById(R.id.editTextBusqueda)
        progressBar = findViewById(R.id.progressBar)

        adapter = SerieAdapter { serieId ->
            irADetalleSerie(serieId)
        }

        recyclerViewSeries.layoutManager = LinearLayoutManager(this)
        recyclerViewSeries.adapter = adapter

        findViewById<View>(R.id.buttonBuscar)?.setOnClickListener {
            val termino = editTextBusqueda.text.toString().trim()
            if (termino.isNotEmpty()) {
                viewModel.buscarSeries(termino)
            } else {
                Toast.makeText(this, "Ingrese un término de búsqueda", Toast.LENGTH_SHORT).show()
            }
        }

        observarViewModel()
    }

    private fun observarViewModel() {
        lifecycleScope.launch {
            viewModel.series.collect { series ->
                adapter.actualizarSeries(series)
            }
        }

        lifecycleScope.launch {
            viewModel.cargando.collect { cargando ->
                progressBar.visibility = if (cargando) View.VISIBLE else View.GONE
            }
        }

        lifecycleScope.launch {
            viewModel.mensajeError.collect { mensaje ->
                mensaje?.let {
                    Toast.makeText(this@SerieActivity, it, Toast.LENGTH_SHORT).show()
                    viewModel.limpiarError()
                }
            }
        }
    }

    private fun irADetalleSerie(serieId: Int) {
        val intent = Intent(this, DetalleSerieActivity::class.java)
        intent.putExtra("SERIE_ID", serieId)
        startActivity(intent)
    }
}