package com.example.tpfinalpent2.datos.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitCliente {

    private const val BASE_URL = "https://api.tvmaze.com/"

    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    val tvMazeApi: TvMazeApi by lazy {
        retrofit.create(TvMazeApi::class.java)
    }
}