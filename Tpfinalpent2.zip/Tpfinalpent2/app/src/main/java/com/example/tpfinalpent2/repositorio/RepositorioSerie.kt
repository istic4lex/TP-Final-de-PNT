package com.example.tpfinalpent2.datos.repositorio

import com.example.tpfinalpent2.datos.api.RetrofitCliente
import com.example.tpfinalpent2.datos.modelo.Serie
import com.example.tpfinalpent2.datos.modelo.ShowSearchResult

class RepositorioSerie {

    private val api = RetrofitCliente.tvMazeApi

    suspend fun buscarSeries(termino: String): Result<List<ShowSearchResult>> {
        return try {
            val response = api.buscarSeries(termino)
            if (response.isSuccessful) {
                response.body()?.let {
                    Result.success(it)
                } ?: Result.failure(Exception("No se encontraron resultados"))
            } else {
                Result.failure(Exception("Error en la búsqueda: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun obtenerSeriePorId(id: Int): Result<Serie> {
        return try {
            val response = api.obtenerSeriePorId(id)
            if (response.isSuccessful) {
                response.body()?.let {
                    Result.success(it)
                } ?: Result.failure(Exception("Serie no encontrada"))
            } else {
                Result.failure(Exception("Error al obtener la serie: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun obtenerSeriesPaginadas(pagina: Int): Result<List<Serie>> {
        return try {
            val response = api.obtenerSeries(pagina)
            if (response.isSuccessful) {
                response.body()?.let {
                    Result.success(it)
                } ?: Result.failure(Exception("No hay series disponibles"))
            } else {
                Result.failure(Exception("Error al obtener series: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}