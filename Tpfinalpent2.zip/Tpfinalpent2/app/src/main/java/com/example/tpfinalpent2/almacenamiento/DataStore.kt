package com.example.tpfinalpent2.datos.almacenamiento

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "configuracion")

class DataStoreManager(private val context: Context) {

    companion object {
        val KEY_NOMBRE_USUARIO = stringPreferencesKey("nombre_usuario")
        val KEY_CONTRASENA = stringPreferencesKey("contrasena")
        val KEY_RECORDAR_SESION = booleanPreferencesKey("recordar_sesion")
        val KEY_SESION_ACTIVA = booleanPreferencesKey("sesion_activa")
    }


    val obtenerUsuario: Flow<Usuario?> = context.dataStore.data.map { preferences ->
        val nombre = preferences[KEY_NOMBRE_USUARIO]
        val contrasena = preferences[KEY_CONTRASENA]
        val recordar = preferences[KEY_RECORDAR_SESION] ?: false

        if (nombre != null && contrasena != null) {
            Usuario(nombre, contrasena, recordar)
        } else {
            null
        }
    }

    val esSesionActiva: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[KEY_SESION_ACTIVA] ?: false
    }

    suspend fun guardarUsuario(usuario: Usuario, recordarSesion: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_NOMBRE_USUARIO] = usuario.nombreUsuario
            preferences[KEY_CONTRASENA] = usuario.contrasena
            preferences[KEY_RECORDAR_SESION] = recordarSesion
            preferences[KEY_SESION_ACTIVA] = true
        }
    }

    suspend fun activarSesion() {
        context.dataStore.edit { preferences ->
            preferences[KEY_SESION_ACTIVA] = true
        }
    }

    suspend fun cerrarSesion() {
        context.dataStore.edit { preferences ->
            preferences.clear()
        }
    }

    suspend fun actualizarEstadoSesion(activo: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_SESION_ACTIVA] = activo
        }
    }
}