package com.example.tpfinalpent2.interfaz.detalle

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.tpfinalpent2.R
import com.example.tpfinalpent2.datos.repositorio.RepositorioSerie
import kotlinx.coroutines.launch

class DetalleSerieActivity : AppCompatActivity() {

    private lateinit var repositorioSerie: RepositorioSerie

    private val viewModel: DetalleSerieViewModel by viewModels {
        object : androidx.lifecycle.ViewModelProvider.Factory {
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return DetalleSerieViewModel(repositorioSerie) as T
            }
        }
    }

    private lateinit var imageViewSerie: ImageView
    private lateinit var textViewNombre: TextView
    private lateinit var textViewResumen: TextView
    private lateinit var textViewGeneros: TextView
    private lateinit var textViewRating: TextView
    private lateinit var textViewIdioma: TextView
    private lateinit var textViewRed: TextView
    private lateinit var textViewEstado: TextView
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalle_serie)

        repositorioSerie = RepositorioSerie()

        imageViewSerie = findViewById(R.id.imageViewSerie)
        textViewNombre = findViewById(R.id.textViewNombre)
        textViewResumen = findViewById(R.id.textViewResumen)
        textViewGeneros = findViewById(R.id.textViewGeneros)
        textViewRating = findViewById(R.id.textViewRating)
        textViewIdioma = findViewById(R.id.textViewIdioma)
        textViewRed = findViewById(R.id.textViewRed)
        textViewEstado = findViewById(R.id.textViewEstado)
        progressBar = findViewById(R.id.progressBar)

        val serieId = intent.getIntExtra("SERIE_ID", -1)

        if (serieId != -1) {
            viewModel.cargarSerie(serieId)
        } else {
            Toast.makeText(this, "Error: ID de serie inválido", Toast.LENGTH_SHORT).show()
            finish()
        }

        observarViewModel()
    }

    private fun observarViewModel() {
        lifecycleScope.launch {
            viewModel.serie.collect { serie ->
                serie?.let {
                    mostrarDetalleSerie(it)
                }
            }
        }

        lifecycleScope.launch {
            viewModel.cargando.collect { cargando ->
                progressBar.visibility = if (cargando) View.VISIBLE else View.GONE
            }
        }

        lifecycleScope.launch {
            viewModel.mensajeError.collect { mensaje ->
                mensaje?.let {
                    Toast.makeText(this@DetalleSerieActivity, it, Toast.LENGTH_SHORT).show()
                    viewModel.limpiarError()
                }
            }
        }
    }

    private fun mostrarDetalleSerie(serie: com.example.tpfinalpent2.datos.modelo.Serie) {
        textViewNombre.text = serie.name

        textViewResumen.text = serie.summary?.replace(Regex("<[^>]*>"), "") ?: "Sin resumen disponible"

        textViewGeneros.text = serie.genres?.joinToString(", ") ?: "Sin género"

        textViewRating.text = serie.rating?.average?.toString() ?: "N/A"

        textViewIdioma.text = serie.language ?: "N/A"

        textViewRed.text = serie.network?.name ?: "N/A"

        textViewEstado.text = serie.status ?: "N/A"

        val imageUrl = serie.imagen?.medium
        if (!imageUrl.isNullOrEmpty()) {
            Glide.with(this)
                .load(imageUrl)
                .placeholder(android.R.drawable.ic_menu_gallery)
                .error(android.R.drawable.ic_menu_report_image)
                .into(imageViewSerie)
        }
    }
}