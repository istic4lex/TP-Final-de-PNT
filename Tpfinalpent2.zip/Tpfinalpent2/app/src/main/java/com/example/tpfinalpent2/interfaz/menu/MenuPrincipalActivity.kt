package com.example.tpfinalpent2.interfaz.menu

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.lifecycle.lifecycleScope
import com.example.tpfinalpent2.R
import com.example.tpfinalpent2.datos.almacenamiento.DataStoreManager
import com.example.tpfinalpent2.interfaz.login.LoginActivity
import com.example.tpfinalpent2.interfaz.series.SerieActivity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MenuPrincipalActivity : AppCompatActivity() {

    private lateinit var dataStoreManager: DataStoreManager

    private lateinit var textViewBienvenida: TextView
    private lateinit var textViewUsuario: TextView
    private lateinit var cardSeries: CardView
    private lateinit var buttonCerrarSesion: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_principal)

        dataStoreManager = DataStoreManager(this)

        textViewBienvenida = findViewById(R.id.textViewBienvenida)
        textViewUsuario = findViewById(R.id.textViewUsuario)
        cardSeries = findViewById(R.id.cardSeries)
        buttonCerrarSesion = findViewById(R.id.buttonCerrarSesion)

        mostrarNombreUsuario()

        cardSeries.setOnClickListener {
            val intent = Intent(this, SerieActivity::class.java)
            startActivity(intent)
        }

        buttonCerrarSesion.setOnClickListener {
            cerrarSesion()
        }
    }

    private fun mostrarNombreUsuario() {
        lifecycleScope.launch {
            val usuario = dataStoreManager.obtenerUsuario.first()
            usuario?.let {
                textViewUsuario.text = it.nombreUsuario
            } ?: run {
                textViewUsuario.text = "Usuario"
            }
        }
    }

    private fun cerrarSesion() {
        lifecycleScope.launch {
            dataStoreManager.cerrarSesion()
            Toast.makeText(this@MenuPrincipalActivity, "Sesión cerrada", Toast.LENGTH_SHORT).show()

            val intent = Intent(this@MenuPrincipalActivity, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }
}