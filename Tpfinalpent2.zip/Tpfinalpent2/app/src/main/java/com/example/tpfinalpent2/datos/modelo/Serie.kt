package com.example.tpfinalpent2.datos.modelo

import com.google.gson.annotations.SerializedName

data class Serie(
    val id: Int,
    val name: String,
    val summary: String?,
    @SerializedName("image")
    val imagen: Imagen?,
    val rating: Rating?,
    val genres: List<String>?,
    val language: String?,
    val network: Network?,
    val status: String?
)

data class Network(
    val name: String?,
    val country: Country?
)

data class Country(
    val name: String?,
    val code: String?
)

data class ShowSearchResult(
    val score: Double?,
    val show: Serie
)