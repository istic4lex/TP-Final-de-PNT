package com.example.tpfinalpent2.datos.api

import com.example.tpfinalpent2.datos.modelo.Serie
import com.example.tpfinalpent2.datos.modelo.ShowSearchResult
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface TvMazeApi {

    @GET("search/shows")
    suspend fun buscarSeries(@Query("q") query: String): Response<List<ShowSearchResult>>

    @GET("shows/{id}")
    suspend fun obtenerSeriePorId(@Path("id") id: Int): Response<Serie>

    @GET("shows")
    suspend fun obtenerSeries(@Query("page") page: Int): Response<List<Serie>>
}