package com.example.tpfinalpent2.interfaz.login

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.tpfinalpent2.R
import com.example.tpfinalpent2.datos.almacenamiento.DataStoreManager
import com.example.tpfinalpent2.datos.repositorio.RepositorioUsuario
import com.example.tpfinalpent2.interfaz.menu.MenuPrincipalActivity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var dataStoreManager: DataStoreManager
    private lateinit var repositorioUsuario: RepositorioUsuario

    private val viewModel: LoginViewModel by viewModels {
        object : androidx.lifecycle.ViewModelProvider.Factory {
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return LoginViewModel(repositorioUsuario) as T
            }
        }
    }

    private lateinit var editTextUsuario: EditText
    private lateinit var editTextContrasena: EditText
    private lateinit var checkBoxRecordar: CheckBox
    private lateinit var buttonIngresar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        dataStoreManager = DataStoreManager(this)
        repositorioUsuario = RepositorioUsuario(dataStoreManager)

        editTextUsuario = findViewById(R.id.editTextUsuario)
        editTextContrasena = findViewById(R.id.editTextContrasena)
        checkBoxRecordar = findViewById(R.id.checkBoxRecordar)
        buttonIngresar = findViewById(R.id.buttonIngresar)

        verificarSesionActiva()

        buttonIngresar.setOnClickListener {
            val usuario = editTextUsuario.text.toString().trim()
            val contrasena = editTextContrasena.text.toString().trim()
            val recordar = checkBoxRecordar.isChecked

            viewModel.login(usuario, contrasena, recordar)
        }

        // Observar cambios del ViewModel
        observarViewModel()
    }

    private fun verificarSesionActiva() {
        lifecycleScope.launch {
            val sesionActiva = dataStoreManager.esSesionActiva.first()
            if (sesionActiva) {
                val usuarioGuardado = dataStoreManager.obtenerUsuario.first()
                if (usuarioGuardado != null) {
                    irAMenuPrincipal()
                }
            }
        }
    }

    private fun observarViewModel() {
        lifecycleScope.launch {
            viewModel.loginExitoso.collect { exitoso ->
                if (exitoso) {
                    irAMenuPrincipal()
                }
            }
        }

        lifecycleScope.launch {
            viewModel.mensajeError.collect { mensaje ->
                mensaje?.let {
                    Toast.makeText(this@LoginActivity, it, Toast.LENGTH_SHORT).show()
                    viewModel.limpiarMensajeError()
                }
            }
        }

        lifecycleScope.launch {
            viewModel.redirigirAMenu.collect { redirigir ->
                if (redirigir) {
                    irAMenuPrincipal()
                }
            }
        }
    }

    private fun irAMenuPrincipal() {
        val intent = Intent(this, MenuPrincipalActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}